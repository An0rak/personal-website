# -*- coding: utf-8 -*-

"""goto-commandline-tool.__main__: executed when goto directory is called as script."""

from .goto import main
main()
